﻿using UnityEngine;

using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class MotionControl : MonoBehaviour {
    Animator anim;
    public AudioSource correct;
    public AudioSource slow_down;
    public AudioSource push_harder;
    public AudioSource speed_up;
    public AudioSource recoil;

    // receiving Thread
    Thread receiveThread;
    // udpclient object
    UdpClient client;

    // public
    public string IP = "127.0.0.1";  //default local
    public int port = 5123;          // define > init
    public int curStatus = -1;
    // infos
    private string lastReceivedUDPPacket = "";

    // start from unity3d
    public void Start()
    {
        init();
    }

    // init
    private void init()
    {     
        receiveThread = new Thread(new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();
    }

    // receive thread
    private void ReceiveData()
    {
        client = new UdpClient(port);
        while (true)
        {
            try
            {
                // Bytes empfangen.
                IPEndPoint anyIP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), port);
                byte[] data = client.Receive(ref anyIP);
                byte status = data[3];
                string text = Convert.ToString(status);
                if (text == "0")
                    curStatus = 0;
                else if (text == "1")
                    curStatus = 1;
                else if (text == "2")
                    curStatus = 2;
                else if (text == "3")
                    curStatus = 3;
                else if (text == "4")
                    curStatus = 4;
                // latest UDPpacket
                lastReceivedUDPPacket = text;
            }
            catch (Exception err)
            {
                print(err.ToString());
            }
        }
    }

    void Awake()
    {
        anim = GetComponent <Animator>();
    }

    void Update()   
	{
		if (Input.GetKey ("escape")) {
			System.Diagnostics.Process.GetCurrentProcess().Kill();
		}
		if (curStatus == 0)
		{
			anim.SetBool("correct", true);
		}
		else if (curStatus == 1)
		{
			anim.SetBool("speed_up", true);
		}
		else if (curStatus == 2)
		{
			anim.SetBool("slow_down", true);
		}
		else if (curStatus == 3)
		{
			anim.SetBool("recoil", true);
		}
		else if (curStatus == 4)
		{
			anim.SetBool("push_harder", true);
		}

    }

	void playCorrectAudio()
	{
		correct.PlayOneShot(correct.clip, 1.0f);
		anim.SetBool("correct", false);
		curStatus = -1;
	}

	void playSpeedupAudio()
	{
		speed_up.PlayOneShot(speed_up.clip, 1.0f);
		anim.SetBool("speed_up", false);
		curStatus = -1;
	}

	void playPushharderAudio()
	{
		push_harder.PlayOneShot(push_harder.clip, 1.0f);
		anim.SetBool("push_harder", false);
		curStatus = -1;
	}

	void playSlowdownAudio()
	{
		slow_down.PlayOneShot(slow_down.clip, 1.0f);
		anim.SetBool("slow_down", false);
		curStatus = -1;
	}

	void playRecoilAudio()
	{
		recoil.PlayOneShot(recoil.clip, 1.0f);
		anim.SetBool("recoil", false);
		curStatus = -1;
	}
}
